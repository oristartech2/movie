package com.oristartech.pojo;

public class TestPojo {
	private int ID;;
	private Long crow;
	private Long row;
	

}
